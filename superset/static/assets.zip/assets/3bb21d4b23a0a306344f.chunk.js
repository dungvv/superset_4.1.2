"use strict";(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[1062],{281788:(e,t,a)=>{a.d(t,{B8:()=>d,TZ:()=>i,mf:()=>l,u7:()=>o});var n=a(431069),r=a(68492);const s=(e,t,a)=>{let n=`api/v1/dashboard/${e}/filter_state`;return t&&(n=n.concat(`/${t}`)),a&&(n=n.concat(`?tab_id=${a}`)),n},i=(e,t,a,i)=>n.Z.put({endpoint:s(e,a,i),jsonPayload:{value:t}}).then((e=>e.json.message)).catch((e=>(r.Z.error(e),null))),o=(e,t,a)=>n.Z.post({endpoint:s(e,void 0,a),jsonPayload:{value:t}}).then((e=>e.json.key)).catch((e=>(r.Z.error(e),null))),d=(e,t)=>n.Z.get({endpoint:s(e,t)}).then((({json:e})=>JSON.parse(e.value))).catch((e=>(r.Z.error(e),null))),l=e=>n.Z.get({endpoint:`/api/v1/dashboard/permalink/${e}`}).then((({json:e})=>e)).catch((e=>(r.Z.error(e),null)))},331062:(e,t,a)=>{a.r(t),a.d(t,{DashboardPage:()=>ue,DashboardPageIdContext:()=>oe,default:()=>he});var n=a(667294),r=a(211965),s=a(616550),i=a(751995),o=a(61988),d=a(828216),l=a(414114),c=a(838703),u=a(708743),h=a(904305),p=a(550810),v=a(514505),f=a(961337),b=a(427600),g=a(23525),m=a(909467),y=a(281788),w=a(14890),S=a(45697),E=a.n(S),x=a(593185),C=a(514278),_=a(920292),I=a(81255);function T(e){return Object.values(e).reduce(((e,t)=>(t&&t.type===I.dW&&t.meta&&t.meta.chartId&&e.push(t.meta.chartId),e)),[])}var D=a(602275),$=a(203741),j=a(599543),O=a(156967);const U=[I.dW,I.xh,I.t];function k(e){return!Object.values(e).some((({type:e})=>e&&U.includes(e)))}var R=a(11794),F=a(135944);const P={actions:E().shape({addSliceToDashboard:E().func.isRequired,removeSliceFromDashboard:E().func.isRequired,triggerQuery:E().func.isRequired,logEvent:E().func.isRequired,clearDataMaskState:E().func.isRequired}).isRequired,dashboardInfo:D.$X.isRequired,dashboardState:D.DZ.isRequired,slices:E().objectOf(D.Rw).isRequired,activeFilters:E().object.isRequired,chartConfiguration:E().object,datasources:E().object.isRequired,ownDataCharts:E().object.isRequired,layout:E().object.isRequired,impressionId:E().string.isRequired,timeout:E().number,userId:E().string};class Z extends n.PureComponent{static onBeforeUnload(e){e?window.addEventListener("beforeunload",Z.unload):window.removeEventListener("beforeunload",Z.unload)}static unload(){const e=(0,o.t)("You have unsaved changes.");return window.event.returnValue=e,e}constructor(e){var t,a;super(e),this.appliedFilters=null!=(t=e.activeFilters)?t:{},this.appliedOwnDataCharts=null!=(a=e.ownDataCharts)?a:{},this.onVisibilityChange=this.onVisibilityChange.bind(this)}componentDidMount(){const e=(0,_.Z)(),{dashboardState:t,layout:a}=this.props,n={is_soft_navigation:$.Yd.timeOriginOffset>0,is_edit_mode:t.editMode,mount_duration:$.Yd.getTimestamp(),is_empty:k(a),is_published:t.isPublished,bootstrap_data_length:e.length},r=(0,O.Z)();r&&(n.target_id=r),this.props.actions.logEvent($.Wl,n),"hidden"===document.visibilityState&&(this.visibilityEventData={start_offset:$.Yd.getTimestamp(),ts:(new Date).getTime()}),window.addEventListener("visibilitychange",this.onVisibilityChange),this.applyCharts()}componentDidUpdate(){this.applyCharts()}UNSAFE_componentWillReceiveProps(e){const t=T(this.props.layout),a=T(e.layout);this.props.dashboardInfo.id===e.dashboardInfo.id&&(t.length<a.length?a.filter((e=>-1===t.indexOf(e))).forEach((t=>{return this.props.actions.addSliceToDashboard(t,(a=e.layout,n=t,Object.values(a).find((e=>e&&e.type===I.dW&&e.meta&&e.meta.chartId===n))));var a,n})):t.length>a.length&&t.filter((e=>-1===a.indexOf(e))).forEach((e=>this.props.actions.removeSliceFromDashboard(e))))}applyCharts(){const{hasUnsavedChanges:e,editMode:t}=this.props.dashboardState,{appliedFilters:a,appliedOwnDataCharts:n}=this,{activeFilters:r,ownDataCharts:s,chartConfiguration:i}=this.props;(0,x.cr)(x.TT.DashboardCrossFilters)&&!i||(t||(0,j.JB)(n,s,{ignoreUndefined:!0})&&(0,j.JB)(a,r,{ignoreUndefined:!0})||this.applyFilters(),e?Z.onBeforeUnload(!0):Z.onBeforeUnload(!1))}componentWillUnmount(){window.removeEventListener("visibilitychange",this.onVisibilityChange),this.props.actions.clearDataMaskState()}onVisibilityChange(){if("hidden"===document.visibilityState)this.visibilityEventData={start_offset:$.Yd.getTimestamp(),ts:(new Date).getTime()};else if("visible"===document.visibilityState){const e=this.visibilityEventData.start_offset;this.props.actions.logEvent($.Ev,{...this.visibilityEventData,duration:$.Yd.getTimestamp()-e})}}applyFilters(){const{appliedFilters:e}=this,{activeFilters:t,ownDataCharts:a,slices:n}=this.props,r=Object.keys(t),s=Object.keys(e),i=new Set(r.concat(s)),o=((e,t)=>{const a=Object.keys(e),n=Object.keys(t),r=(s=a,i=n,[...s.filter((e=>!i.includes(e))),...i.filter((e=>!s.includes(e)))]).filter((a=>e[a]||t[a]));var s,i;return new Set([...a,...n]).forEach((a=>{(0,j.JB)(e[a],t[a])||r.push(a)})),[...new Set(r)]})(a,this.appliedOwnDataCharts);[...i].forEach((a=>{if(!r.includes(a)&&s.includes(a))o.push(...(0,R.H)(a,e[a],n));else if(s.includes(a)){if((0,j.JB)(e[a].values,t[a].values,{ignoreUndefined:!0})||o.push(...(0,R.H)(a,t[a],n)),!(0,j.JB)(e[a].scope,t[a].scope)){const n=(t[a].scope||[]).concat(e[a].scope||[]);o.push(...n)}}else o.push(...(0,R.H)(a,t[a],n))})),this.refreshCharts([...new Set(o)]),this.appliedFilters=t,this.appliedOwnDataCharts=a}refreshCharts(e){e.forEach((e=>{this.props.actions.triggerQuery(!0,e)}))}render(){return this.context.loading?(0,F.tZ)(c.Z,{}):this.props.children}}Z.contextType=C.Zn,Z.propTypes=P,Z.defaultProps={timeout:60,userId:""};const q=Z;var L=a(452256),B=a(797381),M=a(643399),J=a(987915),N=a(174599);const Y=(0,d.$j)((function(e){var t,a,n,r;const{datasources:s,sliceEntities:i,dataMask:o,dashboardInfo:d,dashboardState:l,dashboardLayout:c,impressionId:u,nativeFilters:h}=e;return{timeout:null==(t=d.common)||null==(a=t.conf)?void 0:a.SUPERSET_WEBSERVER_TIMEOUT,userId:d.userId,dashboardInfo:d,dashboardState:l,datasources:s,activeFilters:{...(0,M.De)(),...(0,J.gs)({chartConfiguration:null==(n=d.metadata)?void 0:n.chart_configuration,nativeFilters:h.filters,dataMask:o,allSliceIds:l.sliceIds})},chartConfiguration:null==(r=d.metadata)?void 0:r.chart_configuration,ownDataCharts:(0,J.U3)(o,"ownState"),slices:i.slices,layout:c.present,impressionId:u}}),(function(e){return{actions:(0,w.DE)({setDatasources:p.Fy,clearDataMaskState:N.sh,addSliceToDashboard:m.Pi,removeSliceFromDashboard:m.rL,triggerQuery:L.triggerQuery,logEvent:B.logEvent},e)}}))(q);var Q=a(889662);const V=e=>`dashboard-tabs-reload-${e}`;var A=a(964296),z=a(897205);const K=e=>r.iv`
  body {
    h1 {
      font-weight: ${e.typography.weights.bold};
      line-height: 1.4;
      font-size: ${e.typography.sizes.xxl}px;
      letter-spacing: -0.2px;
      margin-top: ${3*e.gridUnit}px;
      margin-bottom: ${3*e.gridUnit}px;
    }

    h2 {
      font-weight: ${e.typography.weights.bold};
      line-height: 1.4;
      font-size: ${e.typography.sizes.xl}px;
      margin-top: ${3*e.gridUnit}px;
      margin-bottom: ${2*e.gridUnit}px;
    }

    h3,
    h4,
    h5,
    h6 {
      font-weight: ${e.typography.weights.bold};
      line-height: 1.4;
      font-size: ${e.typography.sizes.l}px;
      letter-spacing: 0.2px;
      margin-top: ${2*e.gridUnit}px;
      margin-bottom: ${e.gridUnit}px;
    }
  }
`,W=e=>r.iv`
  .header-title a {
    margin: ${e.gridUnit/2}px;
    padding: ${e.gridUnit/2}px;
  }
  .header-controls {
    &,
    &:hover {
      margin-top: ${e.gridUnit}px;
    }
  }
`,H=e=>r.iv`
  .filter-card-popover {
    width: 240px;
    padding: 0;
    border-radius: 4px;

    &.ant-popover-placement-bottom {
      padding-top: ${e.gridUnit}px;
    }

    &.ant-popover-placement-left {
      padding-right: ${3*e.gridUnit}px;
    }

    .ant-popover-inner {
      box-shadow: 0 0 8px rgb(0 0 0 / 10%);
    }

    .ant-popover-inner-content {
      padding: ${4*e.gridUnit}px;
    }

    .ant-popover-arrow {
      display: none;
    }
  }

  .filter-card-tooltip {
    &.ant-tooltip-placement-bottom {
      padding-top: 0;
      & .ant-tooltip-arrow {
        top: -13px;
      }
    }
  }
`,X=e=>r.iv`
  .ant-dropdown-menu.chart-context-menu {
    min-width: ${43*e.gridUnit}px;
  }
  .ant-dropdown-menu-submenu.chart-context-submenu {
    max-width: ${60*e.gridUnit}px;
    min-width: ${40*e.gridUnit}px;
  }
`,G=e=>r.iv`
  a,
  .ant-tabs-tabpane,
  .ant-tabs-tab-btn,
  .superset-button,
  .superset-button.ant-dropdown-trigger,
  .header-controls span {
    &:focus-visible {
      box-shadow: 0 0 0 2px ${e.colors.primary.dark1};
      border-radius: ${e.gridUnit/2}px;
      outline: none;
      text-decoration: none;
    }
    &:not(
        .superset-button,
        .ant-menu-item,
        a,
        .fave-unfave-icon,
        .ant-tabs-tabpane,
        .header-controls span
      ) {
      &:focus-visible {
        padding: ${e.gridUnit/2}px;
      }
    }
  }
`;var ee=a(478718),te=a.n(ee),ae=a(999547);const ne={},re=()=>{const e=(0,f.rV)(f.dR.DashboardExploreContext,{});return Object.fromEntries(Object.entries(e).filter((([,e])=>!e.isRedundant)))},se=(e,t)=>{const a=re();(0,f.LS)(f.dR.DashboardExploreContext,{...a,[e]:t})},ie=({dashboardPageId:e})=>{const t=(0,d.v9)((({dashboardInfo:t,dashboardState:a,nativeFilters:n,dataMask:r})=>{var s,i,o,d;return{labelsColor:(null==(s=t.metadata)?void 0:s.label_colors)||ne,labelsColorMap:(null==(i=t.metadata)?void 0:i.map_label_colors)||ne,sharedLabelsColors:(0,ae.fy)(null==(o=t.metadata)?void 0:o.shared_label_colors),colorScheme:null==a?void 0:a.colorScheme,chartConfiguration:(null==(d=t.metadata)?void 0:d.chart_configuration)||ne,nativeFilters:Object.entries(n.filters).reduce(((e,[t,a])=>({...e,[t]:te()(a,["chartsInScope"])})),{}),dataMask:r,dashboardId:t.id,filterBoxFilters:(0,M.De)(),dashboardPageId:e}}),d.wU);return(0,n.useEffect)((()=>(se(e,t),()=>{se(e,{...t,isRedundant:!0})})),[t,e]),null},oe=(0,n.createContext)(""),de=(0,n.lazy)((()=>Promise.all([a.e(1216),a.e(5688),a.e(6658),a.e(1323),a.e(8),a.e(7802),a.e(8573),a.e(1247),a.e(981),a.e(9484),a.e(8109),a.e(1108),a.e(9820),a.e(3197),a.e(7317),a.e(8003),a.e(1090),a.e(9818),a.e(868),a.e(1006),a.e(4717),a.e(452)]).then(a.bind(a,413931)))),le=document.title,ce={},ue=({idOrSlug:e})=>{var t;const a=(0,i.Fg)(),w=(0,d.I0)(),S=(0,s.k6)(),E=(0,n.useMemo)((()=>(0,A.x0)()),[]),x=(0,d.v9)((({dashboardInfo:e})=>e&&Object.keys(e).length>0)),C=(0,d.v9)((({dashboardState:e})=>e.editMode)),_=(0,d.v9)((({dashboardState:e})=>e.activeTabs)),T=(0,d.v9)((({dashboardState:e})=>e.directPathToChild)),{addDangerToast:D}=(0,l.e1)(),{result:$,error:j}=(0,u.QU)(e),{result:O,error:U}=(0,u.Es)(e),{result:k,error:R,status:P}=(0,u.JL)(e),Z=(0,n.useRef)(!1),[q,L]=(0,n.useState)({dashboardId:0,config:{}}),B=j||U,M=Boolean($&&O),{dashboard_title:J,css:N,id:ee=0}=$||{};(0,n.useEffect)((()=>{let e=!0;return ee&&(async()=>{try{const e=await fetch("/api/v1/dashboard/periodic_reload_config/");if(!e.ok)return{};const t=await e.json();return(null==t?void 0:t.result)||t}catch{return{}}})().then((t=>{e&&L({dashboardId:ee,config:t})})),()=>{e=!1}}),[ee]);const te=q.dashboardId===ee?q.config:ce,ae=!C&&!0===(null==(t=te.eager_tab_dashboard_ids)?void 0:t.includes(ee)),ne=(0,n.useRef)({activeTabs:_,directPathToChild:T});if(ne.current={activeTabs:_,directPathToChild:T},(0,n.useEffect)((()=>{if(!ee)return;const e=()=>function(e,t){try{sessionStorage.setItem(V(e),JSON.stringify(t))}catch{}}(ee,ne.current);return window.addEventListener("beforeunload",e),()=>window.removeEventListener("beforeunload",e)}),[ee]),(0,n.useEffect)((()=>{const e=()=>{const e=re();(0,f.LS)(f.dR.DashboardExploreContext,{...e,[E]:{...e[E],isRedundant:!0}})};return window.addEventListener("beforeunload",e),()=>{window.removeEventListener("beforeunload",e)}}),[E]),(0,n.useEffect)((()=>{w((0,m.sL)(P))}),[w,P]),(0,n.useEffect)((()=>{if(ee)return(0,z.x_)(ee,(()=>{window.location.reload()}))}),[ee]),(0,n.useEffect)((()=>{ee&&async function(){const e=(0,g.eY)(b.KD.permalinkKey),t=(0,g.eY)(b.KD.nativeFiltersKey),a=(0,g.eY)(b.KD.nativeFilters);let n,r=t||{};if(e){const t=await(0,y.mf)(e);t&&({dataMask:r,activeTabs:n}=t.state)}else t&&(r=await(0,y.B8)(ee,t));if(a&&(r=a),M){var s;const t=function(e,t){try{const a=V(e),n=sessionStorage.getItem(a);if(sessionStorage.removeItem(a),!n)return;const r=JSON.parse(n);if(!Array.isArray(r.activeTabs)||!Array.isArray(r.directPathToChild))return;const s=r.directPathToChild.every(((e,a,n)=>{var r,s;return 0===a?Boolean(t[e]):null==(r=t[n[a-1]])||null==(s=r.children)?void 0:s.includes(e)}));return{activeTabs:r.activeTabs.filter((e=>{var a;return(null==(a=t[e])?void 0:a.type)===I.gn})),directPathToChild:s?r.directPathToChild:[]}}catch{return}}(ee,(null==$?void 0:$.position_data)||{}),a=Boolean(e||(0,g.eY)(b.KD.dashboardFocusedChart)||window.location.hash);let o;if(!a&&t&&({activeTabs:n}=t),e&&null!=(s=n)&&s.length){var i;const e=n[n.length-1],t=null==$||null==(i=$.position_data)?void 0:i[e];t&&(o=[...t.parents||[],e])}Z.current||(Z.current=!0),w((0,h.Y)({history:S,dashboard:$,charts:O,activeTabs:n,directPathToChild:a?o:null==t?void 0:t.directPathToChild,dataMask:r}))}}()}),[M,ee]),(0,n.useEffect)((()=>(J&&(document.title=J),()=>{document.title=le})),[J]),(0,n.useEffect)((()=>"string"==typeof N?(0,v.Z)(N):()=>{}),[N]),(0,n.useEffect)((()=>{R?D((0,o.t)("Error loading chart datasources. Filters may not work correctly.")):w((0,p.Fy)(k))}),[D,k,R,w]),(0,n.useEffect)((()=>{var e;if(!ee||C)return;if(null==(e=te.dashboard_ids)||!e.includes(ee))return;const t=Date.now(),a=()=>{Date.now()-t>=9e5&&window.location.reload()},n=()=>{"visible"===document.visibilityState&&a()},r=setInterval(a,6e4);return document.addEventListener("visibilitychange",n),()=>{clearInterval(r),document.removeEventListener("visibilitychange",n)}}),[ee,C,te]),B)throw B;return M&&x?(0,F.BX)(F.HY,{children:[(0,F.tZ)(r.xB,{styles:[H(a),K(a),X(a),G(a),W(a),"",""]}),(0,F.tZ)(ie,{dashboardPageId:E}),(0,F.tZ)(oe.Provider,{value:E,children:(0,F.tZ)(Q.V.Provider,{value:ae,children:(0,F.tZ)(Y,{children:(0,F.tZ)(de,{})})})})]}):(0,F.tZ)(c.Z,{})},he=ue},889662:(e,t,a)=>{a.d(t,{V:()=>n});const n=(0,a(667294).createContext)(!1)},987915:(e,t,a)=>{a.d(t,{U3:()=>r,b$:()=>o,gs:()=>d});var n=a(680621);const r=(e,t)=>Object.values(e).filter((e=>e[t])).reduce(((e,a)=>({...e,[a.id]:t?a[t]:a})),{}),s=e=>Number(e),i=(e,t)=>{var a,r;const i=(null!=t?t:[]).map(s),o=e.scope,d=null!=(a=null==o?void 0:o.rootPath)?a:[],l=new Set((null!=(r=null==o?void 0:o.excluded)?r:[]).map(s));return 1===d.length&&d[0]===n._4?i.filter((e=>!l.has(e))):null!=e.chartsInScope?e.chartsInScope.map(s):[]},o=(e,t)=>e.some((e=>s(e)===s(t))),d=({chartConfiguration:e,nativeFilters:t,dataMask:a,allSliceIds:n})=>{const r={};return Object.values(a).forEach((({id:a,extraFormData:o})=>{var d;const l=null==t?void 0:t[a];var c;if(l)return void(r[a]={scope:i(l,n),filterType:l.filterType,targets:null!=(c=l.targets)?c:[],values:o});const u=null==e||null==(d=e[a])?void 0:d.crossFilters;var h,p,v,f;u&&(r[a]={scope:(null!=(h=null!=(p=u.chartsInScope)?p:n)?h:[]).map(s),filterType:void 0,targets:null!=(v=null!=(f=u.chartsInScope)?f:n)?v:[],values:o})})),r}},11794:(e,t,a)=>{a.d(t,{H:()=>s});var n=a(10916);function r(e,t){return e.length===Object.keys(t).length}function s(e,t,a){var s;let i=[];const o=Object.keys(a).includes(e)&&(0,n.w0)(t),d=Array.isArray(t.scope)?t.scope:null!=(s=t.chartsInScope)?s:[];o&&(i=function(e,t,a){if(!t[e])return[];const n=[...a.filter((t=>String(t)!==e)),Number(e)],s=new Set(a);return Object.values(t).reduce(((a,i)=>i.slice_id===Number(e)?a:r(n,t)?(a.push(i.slice_id),a):(s.has(i.slice_id)&&a.push(i.slice_id),a)),[])}(e,a,d));const l=t;return(!o||(0,n.A8)(l)||(0,n.kI)(l))&&(i=function(e,t){if(r(t,e))return Object.keys(e).map(Number);const a=new Set(t);return Object.values(e).reduce(((e,t)=>(a.has(t.slice_id)&&e.push(t.slice_id),e)),[])}(a,d)),i}},514505:(e,t,a)=>{function n(e){const t="CssEditor-css",a=document.head||document.getElementsByTagName("head")[0],n=document.querySelector(`.${t}`)||function(e){const t=document.createElement("style");return t.className=e,t.type="text/css",t}(t);return"styleSheet"in n?n.styleSheet.cssText=e:n.innerHTML=e,a.appendChild(n),function(){n.remove()}}a.d(t,{Z:()=>n})},708743:(e,t,a)=>{a.d(t,{schemaEndpoints:()=>x.Kt,CN:()=>n.CN,$K:()=>E.$K,tableEndpoints:()=>E.QD,$O:()=>v,hb:()=>m,QU:()=>y,Es:()=>w,JL:()=>S,L8:()=>_,Xx:()=>x.Xx,SJ:()=>E.SJ,uY:()=>E.uY,zA:()=>E.zA});var n=a(845673),r=a(242190),s=a(667294),i=a(938325),o=a(610362);const d=o.h.injectEndpoints({endpoints:e=>({catalogs:e.query({providesTags:[{type:"Catalogs",id:"LIST"}],query:({dbId:e,forceRefresh:t})=>({endpoint:`/api/v1/database/${e}/catalogs/`,urlParams:{force:t},transformResponse:({json:e})=>e.result.sort().map((e=>({value:e,label:e,title:e})))}),serializeQueryArgs:({queryArgs:{dbId:e}})=>({dbId:e})})})}),{useLazyCatalogsQuery:l,useCatalogsQuery:c,endpoints:u,util:h}=d,p=[];function v(e){const{dbId:t,onSuccess:a,onError:n}=e||{},[r]=l(),o=c({dbId:t,forceRefresh:!1},{skip:!t}),d=(0,i.Z)(((e,t=!1)=>{!e||o.currentData&&!t||r({dbId:e,forceRefresh:t}).then((({isSuccess:e,isError:r,data:s})=>{e&&(null==a||a(s||p,t)),r&&(null==n||n())}))})),u=(0,s.useCallback)((()=>{d(t,!0)}),[t,d]);return(0,s.useEffect)((()=>{d(t,!1)}),[t,d]),{...o,refetch:u}}var f=a(115926);function b({owners:e}){return e?e.map((e=>`${e.first_name} ${e.last_name}`)):null}const g=a.n(f)().encode({columns:["owners.first_name","owners.last_name"],keys:["none"]});function m(e){return(0,r.l6)((0,r.s_)(`/api/v1/chart/${e}?q=${g}`),b)}const y=e=>(0,r.l6)((0,r.s_)(`/api/v1/dashboard/${e}`),(e=>({...e,metadata:e.json_metadata&&JSON.parse(e.json_metadata)||{},position_data:e.position_json&&JSON.parse(e.position_json),owners:e.owners||[]}))),w=e=>(0,r.s_)(`/api/v1/dashboard/${e}/charts`),S=e=>(0,r.s_)(`/api/v1/dashboard/${e}/datasets`);var E=a(123936),x=a(469279);const C=o.h.injectEndpoints({endpoints:e=>({queryValidations:e.query({providesTags:["QueryValidations"],query:({dbId:e,catalog:t,schema:a,sql:n,templateParams:r})=>{let s=r;try{s=JSON.parse(r||"")}catch(e){s=void 0}const i={catalog:t,schema:a,sql:n,...s&&{template_params:s}};return{method:"post",endpoint:`/api/v1/database/${e}/validate_sql/`,headers:{"Content-Type":"application/json"},body:JSON.stringify(i),transformResponse:({json:e})=>e.result}}})})}),{useQueryValidationsQuery:_}=C}}]);
//# sourceMappingURL=3bb21d4b23a0a306344f.chunk.js.map