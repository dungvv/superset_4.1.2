"use strict";(globalThis.webpackChunksuperset=globalThis.webpackChunksuperset||[]).push([[9962],{699962:(e,t,i)=>{i.r(t),i.d(t,{default:()=>P});var n=i(667294),o=i(751995),r=i(768023),a=i(281615),l=i(15746),s=i(731281),c=i(617813),d=i(693450),h=i(655958),u=i(499326),p=i(347106),f=i(570012),g=i(135944);r.D([l.N,s.N,c.N,d.N,h.N,u.N,p.N,f.N]);const m=.38,w=16,v=o.iK.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  font-family: ${({theme:e})=>e.typography.families.sansSerif};
  box-sizing: border-box;
  overflow: hidden;
`,x=o.iK.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  padding: 8px 16px;
  flex-shrink: 0;
`,k=o.iK.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: baseline;
  gap: 6px;
`,y=o.iK.div`
  font-size: 27px;
  font-weight: 700;
  color: ${({color:e,theme:t})=>e||t.colors.grayscale.dark1};
  line-height: 1.2;
`,b=o.iK.div`
  font-size: 25px;
  color: ${({theme:e})=>e.colors.grayscale.dark1};
  font-style: italic;
  white-space: nowrap;
`,D=o.iK.div`
  font-size: 25px;
  color: ${({theme:e})=>e.colors.grayscale.dark1};
  line-height: 1.2;

  body.superset-word-export-capturing & {
    font-size: 25px;
    line-height: 1.2;
    white-space: nowrap;
  }
`,K=o.iK.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  align-items: center;
`,C=o.iK.span`
  color: ${"#1559A6"};
  margin-right: 4px;
`,N=o.iK.div`
  height: 8px;
  flex-shrink: 0;
`,$=o.iK.div`
  flex: 1;
  min-height: 0;
`,z="#2CA02C",R="#D62728",X="#1978D4";function Z(){return"undefined"==typeof window?"":new URLSearchParams(window.location.search).get("time_grain")||""}function B(e){if("undefined"==typeof window)return!1;const t=e.trim();if(!t)return!1;const i=new URL(t,window.location.origin);new URLSearchParams(window.location.search).forEach(((e,t)=>{i.searchParams.has(t)||i.searchParams.set(t,e)}));const n=i.origin===window.location.origin?`${i.pathname}${i.search}${i.hash}`:i.toString();return window.open(n,"_self"),!0}function P(e){const{width:t,height:i,kpiTitle:o,detailUrl:r,kpiGroup:l,currentRatio:s,currentAbsolute:c,showCurrentAbsolute:d,prevRatio:h,kpiTarget:u,bigNumberUnit:p,kpiComparison:f,prevPeriodComparison:P,monthToDateRatio:E,monthToDateComparison:L,echartOptions:T,onContextMenu:G}=e,M=(0,n.useRef)(null),S=(0,n.useRef)(null),A=Math.floor(i*m),U=i-A,I=Math.max(0,U-w),_=function(){const e=Z();return"day"===e||"month"===e||"custom"===e?"cùng kỳ tháng trước":"kỳ trước"}(),j=function(){const e=Z();return"week"===e||"custom"===e}()&&null!==E,F=f.noData&&P.noData&&(!j||L.noData),O=r.trim().length>0,Y=f.noData?"no_data":f.isGood?"passed":"failed",H=e=>null!==e?`${e.toLocaleString("vi-VN",{minimumFractionDigits:2,maximumFractionDigits:2})}${p}`:"N/A";(0,n.useEffect)((()=>{M.current&&(S.current||(S.current=a.S1(M.current)),S.current.setOption(T,!0))}),[T]),(0,n.useEffect)((()=>{const e=()=>{var e;null==(e=S.current)||e.resize()};return window.addEventListener("resize",e),()=>{var t;window.removeEventListener("resize",e),null==(t=S.current)||t.dispose()}}),[]),(0,n.useEffect)((()=>{var e;null==(e=S.current)||e.resize({width:Math.floor(t),height:I})}),[t,I]);const V=(e,t,i,n)=>{const o=null!==i?(0,g.BX)("span",{children:[" ","(",(0,g.tZ)("strong",{children:H(i)}),")"]}):null;if(e.noData)return(0,g.BX)(D,{children:[n,"Không có dữ liệu so với ",t]});const r=void 0===e.isGood?"up"===e.direction?z:"down"===e.direction?R:X:e.isGood?z:R,a=e.isGood?"▲":"▼";return"none"===e.direction?(0,g.BX)(D,{children:[(0,g.tZ)(C,{"aria-hidden":"true",children:"▶"}),n," Không đổi so với ",t,o]}):(0,g.BX)(D,{children:[n,(0,g.tZ)("span",{style:{color:r,marginRight:4},children:a}),H(e.value)," so với ",t,o]})},q=(0,n.useCallback)((e=>{G&&(e.preventDefault(),G(e.clientX,e.clientY))}),[G]),J=(0,n.useCallback)((e=>{O&&(e.stopPropagation(),B(r))}),[O,r]),Q=(0,n.useCallback)((e=>{O&&("Enter"!==e.key&&" "!==e.key||(e.preventDefault(),B(r)))}),[O,r]);return(0,g.BX)(v,{"data-kpi-line-chart":"true","data-kpi-title":o,"data-kpi-group":l,"data-kpi-status":Y,children:[(0,g.BX)(x,{style:{height:A},onContextMenu:q,children:[(0,g.tZ)(k,{children:(0,g.tZ)(y,{onClick:J,onKeyDown:Q,role:O?"button":void 0,tabIndex:O?0:void 0,style:{cursor:O?"pointer":"default"},color:f.noData?void 0:f.isGood?z:R,children:H(s)})}),d&&(0,g.BX)(b,{children:["(",c,")"]}),(0,g.tZ)(N,{}),(0,g.tZ)(K,{children:F?(0,g.tZ)(D,{children:"Không có dữ liệu"}):(0,g.BX)(g.HY,{children:[V(f,"KPI",u),V(P,_,h),j&&V(L,"KPI",null,`Luỹ kế tháng ${H(E)} `)]})})]}),(0,g.tZ)($,{ref:M,style:{width:Math.floor(t),height:I,marginTop:w}})]})}}}]);
//# sourceMappingURL=a48ef65870047951fa01.chunk.js.map